## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 4,
  out.width = "100%"
)
has_lme4 <- requireNamespace("lme4", quietly = TRUE)
has_fdapace <- requireNamespace("fdapace", quietly = TRUE)
has_mgcv <- requireNamespace("mgcv", quietly = TRUE)

## ----generate-data------------------------------------------------------------
library(ggkodom)

set.seed(1234)
n_subj <- 60
ids <- seq_len(n_subj)

make_subject <- function(i) {
  n_obs <- sample(4:8, 1)
  baseline <- rnorm(1, mean = 7.2, sd = 1.2)
  slope <- rnorm(1, mean = -0.05, sd = 0.15)
  times <- sort(sample(0:24, n_obs, replace = FALSE)) # months 0–24, no ties
  values <- baseline + slope * times + rnorm(n_obs, 0, 0.5)
  data.frame(id = paste0("S", i), time = times, hba1c = pmax(4, pmin(12, values)),
             stringsAsFactors = FALSE)
}

df <- do.call(rbind, lapply(ids, make_subject))
head(df, 8)

## ----swimlane-basic, fig.height = 5-------------------------------------------
kodom_swimlane(df,
  id = "id",
  time = "time",
  value = "hba1c",
  color_breaks = c(5.7, 6.5, 8),
  n_sample = 40
)

## ----swimlane-tile, fig.height = 5--------------------------------------------
kodom_swimlane(df,
  id = "id",
  time = "time",
  value = "hba1c",
  geom = "tile",
  time_bins = 8,
  agg_fun = "mean",
  color_breaks = c(5.7, 6.5, 8),
  n_sample = 40
)

## ----swimlane-polar, fig.height = 5, fig.width = 5----------------------------
kodom_swimlane(df,
  id = "id",
  time = "time",
  value = "hba1c",
  coord = "polar",
  color_breaks = c(5.7, 6.5, 8),
  n_sample = 30
)

## ----state-ribbon, fig.height = 5---------------------------------------------
kodom_state(df,
  id = "id",
  time = "time",
  value = "hba1c",
  thresholds = c(5.7, 6.5, 8),
  state_labels = c("Normal", "Pre-DM", "DM", "Poor control"),
  n_sample = 40
)

## ----sort-custom--------------------------------------------------------------
# Order by mean HbA1c, descending
mean_hba1c <- tapply(df$hba1c, df$id, mean)
# setNames creates the named vector kodom_swimlane expects
key <- sort(mean_hba1c, decreasing = TRUE)

kodom_swimlane(df,
  id = "id",
  time = "time",
  value = "hba1c",
  sort_by = key,
  color_breaks = c(5.7, 6.5, 8),
  n_sample = 40
)

## ----smooth-lmer, eval = has_lme4---------------------------------------------
sm_lmer <- suppressMessages(
  kodom_smooth(df,
    method = "lmer",
    id = "id", time = "time", value = "hba1c"
  )
)

kodom_fit(sm_lmer$fit,
  id = "id",
  time = "time",
  color_breaks = c(5.7, 6.5, 8),
  n_sample = 40
)

## ----smooth-lmer-note, eval = !has_lme4, echo = FALSE-------------------------
# message("Install 'lme4' to run this section.")

## ----fpca-fit, eval = has_fdapace---------------------------------------------
sm_fp <- kodom_smooth(df,
  method = "fpca",
  id = "id", time = "time", value = "hba1c"
)
fp <- sm_fp$fit

## ----fpca-note, eval = !has_fdapace, echo = FALSE-----------------------------
# message("Install 'fdapace' to run the FPCA sections.")

## ----fpca-components, eval = has_fdapace, fig.height = 5----------------------
kodom_components(fp, show_mean = TRUE)

## ----fpca-perturbation, eval = has_fdapace, fig.height = 5--------------------
kodom_perturbation(fp, K = 2)

## ----fpca-fit-plot, eval = has_fdapace, fig.height = 5------------------------
ids_fp <- names(fp$inputData$Ly)[seq_len(nrow(fp$xiEst))]

kodom_fit(fp,
  ids = ids_fp,
  data = df,
  id = "id",
  time = "time",
  value = "hba1c",
  color_breaks = c(5.7, 6.5, 8),
  n_sample = 40
)

## ----fpca-scores, eval = has_fdapace------------------------------------------
kodom_scores(fp)

## ----fpca-scores-colored, eval = has_fdapace----------------------------------
mean_val <- tapply(df$hba1c, df$id, mean)
# align to the IDs in the fit
ids_fp <- names(fp$inputData$Ly)[seq_len(nrow(fp$xiEst))]
groups <- as.numeric(mean_val[ids_fp])

kodom_scores(fp, groups = groups)

## ----cluster, eval = has_fdapace----------------------------------------------
cl <- cluster_scores(fp, k = 3, seed = 7)
table(cl)

## ----cluster-scores, eval = has_fdapace---------------------------------------
kodom_scores(fp, groups = cl[ids_fp])

## ----cluster-swimlane, eval = has_fdapace, fig.height = 5---------------------
sort_key <- kodom_sort_scores(fp, pc = 1, ids = ids_fp)

df_cl <- df
df_cl$cluster <- cl[as.character(df_cl$id)]

kodom_swimlane(df_cl,
  id           = "id",
  time         = "time",
  value        = "hba1c",
  sort_by      = sort_key,
  facet_rows   = "cluster",
  color_breaks = c(5.7, 6.5, 8),
  n_sample     = 60
)

## ----customize----------------------------------------------------------------
library(ggplot2)

kodom_swimlane(df,
  id = "id",
  time = "time",
  value = "hba1c",
  color_breaks = c(5.7, 6.5, 8),
  n_sample = 40
) +
  labs(
    title = "HbA1c trajectories (n = 40)",
    subtitle = "Sorted by first observed value",
    x = "Months from enrolment",
    color = "HbA1c (%)"
  ) +
  theme(plot.title = element_text(face = "bold"))

